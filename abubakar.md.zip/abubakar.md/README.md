# ABUBAKAR — GitHub Backup Vault

> A personal web app that lets you upload, store, and recover all your project files through GitHub — from any computer, anywhere in the world.

---

## What Is This?

ABUBAKAR is a self-hosted web app that lives on your GitHub account. It gives you a clean dashboard to:

- **Upload** any project folder or files directly to GitHub as a private repo
- **Browse** all your GitHub repos in one place
- **Download** any project back to your PC as a ZIP file
- **Delete** repos you no longer need
- **Track** every upload and download in an activity log

It works entirely in your browser — no server, no subscription, no third-party service. Just you and your GitHub account.

---

## What You Will Need

- A GitHub account (free)
- A modern browser (Chrome, Firefox, Edge, Safari)
- The `index.html` file (included in this repo)

That's it.

---

## Step-by-Step Setup

### Step 1 — Create a GitHub repo for this app

1. Go to [github.com](https://github.com) and sign in
2. Click the **+** icon at the top right → **New repository**
3. Fill in the details:
   - **Repository name:** `abubakar`
   - **Visibility:** Public *(must be public for GitHub Pages to work on free accounts)*
   - **Do NOT** check "Add a README file" or any other initialization option
4. Click **Create repository**

---

### Step 2 — Upload the app file

1. On the new empty repo page, click **Add file → Upload files**
2. Drag and drop the `index.html` file into the upload area
3. Scroll down and click **Commit changes**

---

### Step 3 — Enable GitHub Pages

This makes the app accessible as a website.

1. In your repo, click **Settings** (top menu)
2. In the left sidebar, click **Pages**
3. Under **Source**, select:
   - Branch: `main`
   - Folder: `/ (root)`
4. Click **Save**

Wait about 1–2 minutes, then your app will be live at:

```
https://YOUR-GITHUB-USERNAME.github.io/abubakar
```

Replace `YOUR-GITHUB-USERNAME` with your actual GitHub username.

> Bookmark this URL or set it as your browser's home page. This is how you open ABUBAKAR from any computer.

---

### Step 4 — Create a Personal Access Token

This is the password you will use to sign in to ABUBAKAR. It gives the app permission to read and write to your GitHub account.

1. Go to [github.com/settings/tokens](https://github.com/settings/tokens)
2. Click **Generate new token → Generate new token (classic)**
3. Fill in the form:
   - **Note:** `ABUBAKAR Vault`
   - **Expiration:** Choose `No expiration` or `1 year`
4. Under **Select scopes**, check exactly these three:
   - ✅ `repo` — the top-level checkbox (this includes all sub-options automatically)
   - ✅ `read:user` — found inside the `user` section
   - ✅ `delete_repo` — standalone checkbox below the user section
   - Leave everything else unchecked
5. Scroll to the bottom and click **Generate token**
6. **Copy the token immediately** — GitHub only shows it once. It starts with `ghp_`

> Store this token somewhere safe, like a password manager or a private note. If you lose it, you can always generate a new one by repeating this step.

---

### Step 5 — Sign In and Start Using It

1. Open your ABUBAKAR URL: `https://YOUR-USERNAME.github.io/abubakar`
2. Paste your Personal Access Token into the sign-in box
3. Click **Sign in with token**

You are now inside your vault. All your GitHub repos will load automatically.

---

## How to Use ABUBAKAR

### Uploading a Project

1. Click **Upload** in the left sidebar
2. Drag your project files into the drop zone, or click to browse
3. Give the repo a name (e.g. `my-website-2025`)
4. Add a description if you want
5. Make sure **"Save as private repo"** is toggled on (it is by default)
6. Click **Upload to GitHub**

A progress bar will show the upload. When it says "Saved to GitHub ✓", your files are safely stored as a private repo on your GitHub account.

> **File size limit:** GitHub's API allows up to 100 MB per individual file. If a single file is larger than that, zip it first, then upload the ZIP. GitHub gives you unlimited private repos and up to 1 GB per repo on a free account.

---

### Downloading a Project

1. Click **My repos** in the left sidebar
2. Find the project you want
3. Click the green **Download** button on that repo card
4. A ZIP file will download to your PC containing the entire project

---

### Browsing Your Repos

- Use the **search bar** to find a repo by name or description
- Use the **filter buttons** (All / Private / Public) to narrow down the list
- Click the external link icon on any repo card to open it directly on GitHub

---

### Deleting a Repo

1. Find the repo in **My repos**
2. Click the red trash icon on the right
3. Confirm in the popup dialog

> This permanently deletes the repo from GitHub. There is no undo. Only delete something if you are sure you no longer need it.

---

## How to Recover Your Projects on a New PC

If you lose your PC, get a new one, or need to access your projects from anywhere:

1. Open any browser and go to your ABUBAKAR URL:
   ```
   https://YOUR-USERNAME.github.io/abubakar
   ```
2. Sign in with your Personal Access Token
3. Go to **My repos**, find the project you need, and click **Download**
4. Extract the ZIP file and your project is restored

That's the entire recovery process.

---

## Security Notes

| Topic | Details |
|---|---|
| Where your token is stored | Only in your browser's `sessionStorage` — it clears automatically when you close the tab |
| Is your token sent anywhere else? | No — it goes only to `api.github.com`, nowhere else |
| Who can see your private repos? | Only you, using your GitHub account |
| What if someone else opens the URL? | They see the sign-in screen and cannot access anything without your token |
| Is the app itself safe to share? | Yes — the `index.html` file contains no secrets or tokens |

---

## Generating a New Token (If Yours Expires or Gets Lost)

1. Go to [github.com/settings/tokens](https://github.com/settings/tokens)
2. Click **Generate new token (classic)**
3. Follow the same steps as Step 4 above
4. Paste the new token when signing in to ABUBAKAR

---

## Troubleshooting

**"Bad credentials" error when signing in**
Your token may have expired or been deleted. Generate a new one following Step 4.

**"Not Found" error when uploading**
Make sure the repo name only contains letters, numbers, hyphens, and underscores. No spaces or special characters.

**Upload fails on a large file**
Individual files must be under 100 MB. Zip the file first, then upload the ZIP.

**The GitHub Pages URL shows a 404**
Wait 2–3 minutes after enabling Pages and try again. GitHub sometimes takes a moment to deploy.

**Repos are not showing up**
Click the **Refresh** button on the Dashboard, or sign out and sign back in.

---

## Folder Structure of This Repo

```
abubakar/
└── index.html       ← The entire app (one file, no dependencies)
└── README.md        ← This guide
```

The entire ABUBAKAR app is a single self-contained HTML file. No frameworks, no build tools, no installation required. Everything runs in your browser.

---

## Summary Checklist

Use this as a quick reference when setting up on a new machine:

- [ ] Create a GitHub repo named `abubakar` (public)
- [ ] Upload `index.html` to the repo
- [ ] Enable GitHub Pages (Settings → Pages → main → Save)
- [ ] Generate a Personal Access Token with `repo`, `read:user`, and `delete_repo` scopes
- [ ] Open `https://YOUR-USERNAME.github.io/abubakar`
- [ ] Sign in with your token
- [ ] Done ✓

---

*Built with the GitHub REST API. No external services, no data collection, no tracking.*
